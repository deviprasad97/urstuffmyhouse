Parameters
==========

Cocorico application parameters are defined in the following files:

* Environment dependant parameters: `app/config/parameters.yml.dist`: 
* Environment independent parameters: `Cocorico/CoreBundle/Resources/config/parameters.yml`

